#!/system/bin/sh
{
	MODDIR=${0%/*}
	. "$MODDIR/config"

	rm "/data/adb/zee_ytm/base.apk"
	rmdir "/data/adb/zee_ytm"
	rm "/data/adb/post-fs-data.d/$PKG_NAME-uninstall.sh"
} &
